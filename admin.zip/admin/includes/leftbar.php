<nav class="ts-sidebar">
			<ul class="ts-sidebar-menu">
			
				<li class="ts-label">Main</li>
				<li><a href="dashboard.php"><i class="fa fa-dashboard"></i> Dashboard</a></li>
			
				<li><a href="#"><i class="fa fa-files-o"></i> Breaking news</a>
				<ul>
					<li><a href="add-breaking.php">Add Breaking</a></li>
					<li><a href="manage-breaking.php">Manage Breaking News</a></li>
				</ul>
				</li>
				<li><a href="#"><i class="fa fa-files-o"></i> Notice Board</a>
				<ul>
					<li><a href="add-notice.php">Add Notice</a></li>
					<li><a href="manage-notice.php">Manage Notice</a></li>
				</ul>
				
				</li><li><a href="#"><i class="fa fa-files-o"></i> Resutl</a>
				<ul>
					<li><a href="studentresult.php">Add result</a></li>
					<li><a href="#">Manage result</a></li>
				</ul>
				</li>


				<li><a href="add-teacher.php"><i class="fa fa-edit"></i> Add Teacher</a></li>
				<li><a href="teacher-list.php"><i class="fa fa-users"></i> Teacher List</a></li>

				<li><a href="manage-conactusquery.php"><i class="fa fa-desktop"></i> Manage Conatctus Query</a></li>
				<li><a href="manage-pages.php"><i class="fa fa-files-o"></i> Manage Pages</a></li>
				<li><a href="update-contactinfo.php"><i class="fa fa-files-o"></i> Update Contact Info</a></li>


			</ul>
</nav>